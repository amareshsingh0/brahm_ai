"""
Panchang service — wraps scripts/panchang.py Panchang class.
Single source of calculation truth (no duplicate logic here).
"""
import sys, os
from typing import Optional

# Import Panchang from the scripts directory on the VM
# Path: ~/books/scripts/panchang.py
_scripts_dir = os.path.join(os.path.expanduser("~/books"), "scripts")
if _scripts_dir not in sys.path:
    sys.path.insert(0, _scripts_dir)

try:
    from panchang import Panchang
    PANCHANG_AVAILABLE = True
except Exception as _e:
    PANCHANG_AVAILABLE = False
    print(f"WARNING: panchang.py import failed — {_e}")


def get_panchang(year: int, month: int, day: int, lat: float, lon: float, tz: float) -> dict:
    """
    Return PanchangResponse-shaped dict for the given date and location.
    Raises RuntimeError if pyswisseph unavailable.
    """
    if not PANCHANG_AVAILABLE:
        raise RuntimeError("Panchang module unavailable (pyswisseph not installed)")

    p = Panchang(year, month, day, lat=lat, lon=lon, tz=tz)
    raw = p.to_dict()

    # Normalize to API contract shape
    tithi = raw["tithi"]
    vara = raw["vara"]
    nakshatra = raw["nakshatra"]
    yoga = raw["yoga"]
    karana = raw["karana"]

    return {
        "vara": {
            "name": vara.get("name", ""),
            "hindi": vara.get("hindi", ""),
            "lord": vara.get("lord", ""),
        },
        "tithi": {
            "name": tithi.get("name", ""),
            "hindi": tithi.get("hindi", ""),
            "paksha": tithi.get("paksha", ""),
            "end_time": tithi.get("end_time", tithi.get("end_time_str", "")),
        },
        "nakshatra": {
            "name": nakshatra.get("name", ""),
            "hindi": nakshatra.get("hindi", ""),
            "pada": nakshatra.get("pada", 1),
            "lord": nakshatra.get("lord", ""),
        },
        "yoga": {
            "name": yoga.get("name", ""),
            "hindi": yoga.get("hindi", ""),
            "is_auspicious": bool(yoga.get("is_auspicious", True)),
        },
        "karana": {
            "name": karana.get("name", ""),
            "hindi": karana.get("hindi", ""),
        },
        "sunrise": raw.get("sunrise", ""),
        "sunset": raw.get("sunset", ""),
        "abhijit_muhurta": {
            "start": raw["abhijit_muhurta"]["start"],
            "end": raw["abhijit_muhurta"]["end"],
        },
        "rahukaal": {
            "start": raw["rahukaal"]["start"],
            "end": raw["rahukaal"]["end"],
        },
    }
