"""
Eclipse (Grahan) calendar — uses pyswisseph eclipse functions.
"""
from fastapi import APIRouter, HTTPException, Query
from api.config import EPHE_PATH

router = APIRouter()

_EFFECTS = {
    "Total Solar":   "Powerful transformation. Meditation and japa yield amplified results.",
    "Annular Solar": "New beginnings. Avoid starting new ventures during eclipse.",
    "Partial Solar": "Subtle shifts in external circumstances. Observe silence.",
    "Total Lunar":   "Emotional cleansing. Deep introspection and prayer recommended.",
    "Partial Lunar": "Inner reflection. Release what no longer serves you.",
    "Penumbral":     "Gentle cosmic nudge. Heightened sensitivity and awareness.",
}


@router.get("/grahan")
def grahan(year: int = Query(default=2026)):
    try:
        import swisseph as swe
        swe.set_ephe_path(EPHE_PATH)

        eclipses = []
        jd_start = swe.julday(year, 1, 1, 0.0)
        jd_end = swe.julday(year + 1, 1, 1, 0.0)

        # Solar eclipses
        jd = jd_start
        while jd < jd_end:
            ret = swe.sol_eclipse_when_glob(jd, swe.FLG_SWIEPH)
            if ret[0] < 0: break
            eclipse_jd = ret[1][0]
            if eclipse_jd >= jd_end: break
            etype = ret[0]
            if etype & swe.ECL_TOTAL:     label = "Total Solar"
            elif etype & swe.ECL_ANNULAR: label = "Annular Solar"
            else:                          label = "Partial Solar"
            y, m, d, h = swe.revjul(eclipse_jd)
            eclipses.append({
                "date": f"{int(y):04d}-{int(m):02d}-{int(d):02d}",
                "type": label,
                "duration_minutes": 180,
                "spiritual_effect": _EFFECTS.get(label, ""),
            })
            jd = eclipse_jd + 20

        # Lunar eclipses
        jd = jd_start
        while jd < jd_end:
            ret = swe.lun_eclipse_when(jd, swe.FLG_SWIEPH)
            if ret[0] < 0: break
            eclipse_jd = ret[1][0]
            if eclipse_jd >= jd_end: break
            etype = ret[0]
            if etype & swe.ECL_TOTAL:         label = "Total Lunar"
            elif etype & swe.ECL_PARTIAL:     label = "Partial Lunar"
            else:                              label = "Penumbral"
            y, m, d, h = swe.revjul(eclipse_jd)
            eclipses.append({
                "date": f"{int(y):04d}-{int(m):02d}-{int(d):02d}",
                "type": label,
                "duration_minutes": 270,
                "spiritual_effect": _EFFECTS.get(label, ""),
            })
            jd = eclipse_jd + 20

        eclipses.sort(key=lambda x: x["date"])
        return {"year": year, "eclipses": eclipses}

    except ImportError:
        raise HTTPException(status_code=503, detail="pyswisseph not installed")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
