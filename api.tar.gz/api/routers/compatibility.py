"""
Compatibility router — 36 Guna matching based on Moon nakshatra.
"""
from datetime import datetime
from fastapi import APIRouter, HTTPException
from api.models.compatibility import CompatibilityRequest, CompatibilityResponse, GunaScore, MangalDosha
from api.services.kundali_service import calc_kundali
from api.config import NAKSHATRAS

router = APIRouter()

# Simplified Guna table (Ashta Koota)
_GUNA_MAX = [1, 2, 3, 4, 5, 7, 6, 8]  # Varna, Vashya, Tara, Yoni, Graha Maitri, Gana, Bhakuta, Nadi
_GUNA_NAMES = ["Varna", "Vashya", "Tara", "Yoni", "Graha Maitri", "Gana", "Bhakuta", "Nadi"]
_GUNA_DESCS = [
    "Spiritual compatibility", "Dominance & control", "Star compatibility",
    "Nature & instinct", "Planetary friendship", "Temperament (Dev/Manav/Rakshasa)",
    "Moon sign compatibility", "Health & genetic compatibility"
]

def _moon_nak_idx(data: dict) -> int:
    return NAKSHATRAS.index(data["grahas"]["Chandra"]["nakshatra"])

def _has_mangal_dosha(data: dict) -> bool:
    return data["grahas"]["Mangal"]["house"] in [1, 2, 4, 7, 8, 12]

def _calc_gunas(nak_a: int, nak_b: int) -> list:
    gunas = []
    for i, (name, max_pts, desc) in enumerate(zip(_GUNA_NAMES, _GUNA_MAX, _GUNA_DESCS)):
        # Simplified scoring: use nakshatra arithmetic
        diff = abs(nak_a - nak_b) % 9
        score = max(0, max_pts - (diff % (max_pts + 1)))
        gunas.append(GunaScore(name=name, score=score, max=max_pts, desc=desc))
    return gunas

@router.post("/compatibility", response_model=CompatibilityResponse)
def compatibility(req: CompatibilityRequest):
    results = []
    for person in [req.person_a, req.person_b]:
        try:
            dt = datetime.strptime(f"{person.date} {person.time}", "%Y-%m-%d %H:%M")
        except ValueError as e:
            raise HTTPException(status_code=422, detail=str(e))
        data, err = calc_kundali(
            year=dt.year, month=dt.month, day=dt.day,
            hour=dt.hour, minute=dt.minute,
            lat=person.lat, lon=person.lon, tz=person.tz,
        )
        if err:
            raise HTTPException(status_code=500, detail=err)
        results.append(data)

    nak_a = _moon_nak_idx(results[0])
    nak_b = _moon_nak_idx(results[1])
    gunas = _calc_gunas(nak_a, nak_b)
    total = sum(g.score for g in gunas)
    pct = int(total / 36 * 100)
    verdict = "Excellent" if pct >= 72 else "Good" if pct >= 55 else "Average" if pct >= 36 else "Poor"

    return CompatibilityResponse(
        total_score=total,
        max_score=36,
        percentage=pct,
        verdict=verdict,
        gunas=gunas,
        mangal_dosha=MangalDosha(
            person_a=_has_mangal_dosha(results[0]),
            person_b=_has_mangal_dosha(results[1]),
        ),
    )
