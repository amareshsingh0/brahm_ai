from typing import List
from pydantic import BaseModel
from .common import BirthDetails


class GunaScore(BaseModel):
    name: str
    score: int
    max: int
    desc: str


class MangalDosha(BaseModel):
    person_a: bool
    person_b: bool


class CompatibilityRequest(BaseModel):
    person_a: BirthDetails
    person_b: BirthDetails


class CompatibilityResponse(BaseModel):
    total_score: int
    max_score: int = 36
    percentage: int
    verdict: str
    gunas: List[GunaScore]
    mangal_dosha: MangalDosha
