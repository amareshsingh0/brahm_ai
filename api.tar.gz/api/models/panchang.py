from typing import Optional
from pydantic import BaseModel


class VaraData(BaseModel):
    name: str
    hindi: str
    lord: str


class TithiData(BaseModel):
    name: str
    hindi: str
    paksha: str
    end_time: str


class NakshatraData(BaseModel):
    name: str
    hindi: str
    pada: int
    lord: str


class YogaData(BaseModel):
    name: str
    hindi: str
    is_auspicious: bool


class KaranaData(BaseModel):
    name: str
    hindi: str


class MuhurtaSlot(BaseModel):
    start: str
    end: str


class PanchangRequest(BaseModel):
    date: str        # YYYY-MM-DD
    lat: float
    lon: float
    tz: float = 5.5


class PanchangResponse(BaseModel):
    vara: VaraData
    tithi: TithiData
    nakshatra: NakshatraData
    yoga: YogaData
    karana: KaranaData
    sunrise: str
    sunset: str
    abhijit_muhurta: MuhurtaSlot
    rahukaal: MuhurtaSlot
